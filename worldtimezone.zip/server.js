var express = require("express");
var fs = require("fs");
var path = require("path");
var bodyparser = require("body-parser");

var app = express();
app.use(bodyparser());
app.use(express.static(path.join(__dirname, "static")));


app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");





app.get("/", function (req, res) {
	//res.render("signup")
	//res.sendFile(__dirname + "/home.html");
	res.render("home", { message: false });
});

var PORT = process.env.PORT || 3000;
app.listen(PORT, function () {
	console.log("listening on port" + PORT);
});